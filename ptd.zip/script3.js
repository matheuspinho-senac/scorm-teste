document.addEventListener('DOMContentLoaded', function () {
    var formData = JSON.parse(localStorage.getItem("formData"));
    var horasRestantes = parseInt(localStorage.getItem("horasRestantes"));
    var situacaoAtual = parseInt(localStorage.getItem("situacaoAtual"));
    var totalHorasUC = parseInt(formData.ch);
    var todasSituacoes = JSON.parse(localStorage.getItem("todasSituacoes")) || [];
    var situacaoModificada = false;

    // Inicializa horasRestantes se não estiver definido
    if (!horasRestantes || isNaN(horasRestantes)) {
        horasRestantes = totalHorasUC;
        localStorage.setItem("horasRestantes", horasRestantes.toString());
    }

    // Atualiza o título da página com o número da situação atual
    document.getElementById("situacaoTitle").textContent = `Situação de Aprendizagem ${situacaoAtual}`;
    
    // Cria e exibe o elemento de informação de horas restantes
    var horasRestantesDiv = document.createElement('div');
    horasRestantesDiv.className = 'horas-restantes-info';
    horasRestantesDiv.style.marginBottom = '20px';
    horasRestantesDiv.style.padding = '10px';
    horasRestantesDiv.style.backgroundColor = '#f0f0f0';
    horasRestantesDiv.style.borderRadius = '5px';
    horasRestantesDiv.style.textAlign = 'center';
    horasRestantesDiv.innerHTML = `<strong>Horas restantes para distribuir:</strong> ${horasRestantes}h`;

    var form = document.getElementById("situacaoForm");
    form.insertBefore(horasRestantesDiv, form.firstChild);

    // Carregar dados salvos da situação atual, se existirem
    function loadSituacaoData() {
        if (todasSituacoes[situacaoAtual - 1]) {
            const situacaoData = todasSituacoes[situacaoAtual - 1];
            document.getElementById("nomeSituacao").value = situacaoData.nomeSituacao || '';
            document.getElementById("nAulas").value = situacaoData.quantidadeAulas || '';
            document.getElementById("indicadores").value = situacaoData.indicadores || '';
            document.getElementById("conhecimentos").value = situacaoData.conhecimentos || '';
            document.getElementById("habilidades").value = situacaoData.habilidades || '';
            document.getElementById("atitudes").value = situacaoData.atitudes || '';
            document.getElementById("contexto").value = situacaoData.contexto || '';

            // Restaura as marcas formativas selecionadas
            if (situacaoData.marcasFormativas) {
                situacaoData.marcasFormativas.forEach(marca => {
                    const checkbox = Array.from(document.querySelectorAll('input[name="marcasFormativas"]'))
                        .find(cb => cb.value === marca);
                    if (checkbox) checkbox.checked = true;
                });
            }

            // Ajusta a altura de todos os textareas
            document.querySelectorAll('textarea[data-auto-expand]').forEach(textarea => {
                handleTextareaInput({ target: textarea });
            });
        }
    }

    // Validação da entrada de horas
    document.getElementById("nAulas").addEventListener('change', function(e) {
        var valorInserido = parseInt(e.target.value);
        if (isNaN(valorInserido) || valorInserido <= 0) {
            alert("Por favor, insira um valor válido maior que 0.");
            e.target.value = "";
            return;
        }

        if (valorInserido > totalHorasUC) {
            alert(`A carga horária não pode exceder o total da UC (${totalHorasUC}h)`);
            e.target.value = totalHorasUC;
            return;
        }

        // Verifica o limite de horas considerando o valor anterior
        const situacaoAtualData = todasSituacoes[situacaoAtual - 1];
        const horasAnteriores = situacaoAtualData ? parseInt(situacaoAtualData.quantidadeAulas) || 0 : 0;
        const horasDisponíveis = horasRestantes + horasAnteriores;

        if (valorInserido > horasDisponíveis) {
            alert(`A carga horária não pode exceder as horas restantes (${horasDisponíveis}h)`);
            e.target.value = horasDisponíveis;
        }
        
        situacaoModificada = true;
    });

    // Função para ajustar altura dos textareas
    function handleTextareaInput(event) {
        const textarea = event.target;
        textarea.style.height = 'auto';
        textarea.style.height = textarea.scrollHeight + 'px';
        situacaoModificada = true;
    }

    // Adiciona o evento de auto-expand para todos os textareas
    document.querySelectorAll('textarea[data-auto-expand]').forEach(textarea => {
        textarea.addEventListener('input', handleTextareaInput);
    });

    // Tratamento do botão Voltar
    document.getElementById("backButton").addEventListener('click', function(event) {
        event.preventDefault();
        if (situacaoModificada) {
            saveSituacaoData();
        }
        if (situacaoAtual > 1) {
            situacaoAtual--;
            localStorage.setItem("situacaoAtual", situacaoAtual.toString());
            window.location.href = "pdf.html";
        } else {
            window.location.href = "index.html";
        }
    });

    // Função para salvar os dados da situação
    function saveSituacaoData() {
        var situacaoData = {
            nomeSituacao: document.getElementById("nomeSituacao").value,
            quantidadeAulas: document.getElementById("nAulas").value,
            indicadores: document.getElementById("indicadores").value,
            conhecimentos: document.getElementById('conhecimentos').value,
            habilidades: document.getElementById('habilidades').value,
            atitudes: document.getElementById('atitudes').value,
            contexto: document.getElementById("contexto").value,
            marcasFormativas: Array.from(document.querySelectorAll('input[name="marcasFormativas"]:checked')).map(cb => cb.value)
        };

        todasSituacoes[situacaoAtual - 1] = situacaoData;
        localStorage.setItem("todasSituacoes", JSON.stringify(todasSituacoes));
        situacaoModificada = false;
    }

    function updateHorasRestantes() {
        var horasUtilizadas = parseInt(document.getElementById("nAulas").value);
        const situacaoAtualData = todasSituacoes[situacaoAtual - 1];
        const horasAnteriores = situacaoAtualData ? parseInt(situacaoAtualData.quantidadeAulas) || 0 : 0;
        const diferenca = horasUtilizadas - horasAnteriores;
        horasRestantes -= diferenca;
        localStorage.setItem("horasRestantes", horasRestantes.toString());
    }

    // Tratamento do envio do formulário
    document.getElementById("situacaoForm").addEventListener('submit', function(event) {
        event.preventDefault();

        var horasUtilizadas = parseInt(document.getElementById("nAulas").value);
        if (isNaN(horasUtilizadas) || horasUtilizadas <= 0) {
            alert("Por favor, insira um valor válido para as horas.");
            return;
        }

        var checkboxes = document.querySelectorAll('input[name="marcasFormativas"]:checked');
        if (checkboxes.length === 0) {
            alert("Por favor, selecione pelo menos uma Marca Formativa antes de avançar.");
            return;
        }

        // Calcula novas horas restantes considerando valores anteriores
        const situacaoAtualData = todasSituacoes[situacaoAtual - 1];
        const horasAnteriores = situacaoAtualData ? parseInt(situacaoAtualData.quantidadeAulas) || 0 : 0;
        const diferenca = horasUtilizadas - horasAnteriores;
        const novasHorasRestantes = horasRestantes - diferenca;

        if (novasHorasRestantes < 0) {
            alert("A distribuição de horas excede o total disponível.");
            return;
        }

        // Salva os dados do formulário e atualiza as horas restantes
        saveSituacaoData();
        updateHorasRestantes();
        

        // Navega para a próxima página
        window.location.href = "pdf.html";
    });

    // Marca o formulário como modificado quando qualquer input muda
    document.querySelectorAll('input, textarea').forEach(element => {
        element.addEventListener('change', () => {
            situacaoModificada = true;
        });
    });

    // Carrega os dados salvos ao iniciar a página
    loadSituacaoData();
});